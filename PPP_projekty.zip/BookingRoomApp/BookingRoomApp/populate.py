from app import app,db
from datetime import datetime
from app.models import *

# add team
team=Team(id=1,teamName='Admin')
db.session.add(team)
team=Team(id=2,teamName='IT')
db.session.add(team)
team=Team(id=3,teamName='HR')
db.session.add(team)
team=Team(id=4,teamName='Kadry')
db.session.add(team)
team=Team(id=5,teamName='Zarząd')
db.session.add(team)

# add admin & users
user=User(id=1,username='admin',fullname='admin',position='admin',teamId=1)
user.set_password('admin')
db.session.add(user)

user=User(id=2,username='Jan1',fullname='Nowak',position='Prezes',teamId=5)
user.set_password('jan')
db.session.add(user)
user=User(id=3,username='Jan2',fullname='Kowalski',position='Senior developer',teamId=2)
user.set_password('jan')
db.session.add(user)
user=User(id=4,username='Jan3',fullname='Barański',position='Junior developer',teamId=2)
user.set_password('jan')
db.session.add(user)
user=User(id=5,username='Anna1',fullname='Kowalska',position='Rekruter',teamId=3)
user.set_password('anna')
db.session.add(user)
user=User(id=6,username='Anna2',fullname='Nowak',position='Kadrowa',teamId=4)
user.set_password('anna')
db.session.add(user)


# add rooms
room=Room(id=1,roomName='Szklarnia',telephone=True,projector=True,whiteboard=True,cost=500)
db.session.add(room)
room=Room(id=2,roomName='Kuchnia',telephone=False,projector=False,whiteboard=False,cost=3000)
db.session.add(room)


# add business partners
partner=Businesspartner(id=1,name='Ziomek',representing='Avengers',position='Szef')
db.session.add(partner)
partner=Businesspartner(id=2,name='Killer',representing='Killer',position='Nikt')
db.session.add(partner)
partner=Businesspartner(id=3,name='Kraken',representing='Piraci z Karaibów',position='Władca')
db.session.add(partner)

db.session.commit()